import { Reducer } from "../StockReducer/Reducer";
import { createStore } from "redux";

export const Store = createStore(Reducer,{})
