export const Action_type = {
    Add_To_Watchlist : 'Add_To_Watchlist',
    Remove_From_Watchlist : 'Remove_From_Watchlist'
}